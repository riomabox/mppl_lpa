<?php
unset(
        $_SESSION['username'],
        $_SESSION['userid'],
        $_SESSION['name']
);
?>